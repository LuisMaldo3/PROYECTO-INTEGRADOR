package pe.tecsup.vynk.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("usuarios")
public class Usuario {

    @Id
    private String id;

    @Indexed(unique = true)
    private String correo;

    private String nombre;
    private String rol = Roles.USUARIO;
    private boolean activo = true;
    private String areaTecsup; // Asignada/verificada por la institución, no por el alumno
    private boolean areaVerificada;
    private String passwordHash; // null si el usuario solo entra con Google

    public String getAreaTecsup() { return areaTecsup; }
    public void setAreaTecsup(String area) { this.areaTecsup = area; }
    public boolean isAreaVerificada() { return areaVerificada; }
    public void setAreaVerificada(boolean b) { areaVerificada = b; }
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
}