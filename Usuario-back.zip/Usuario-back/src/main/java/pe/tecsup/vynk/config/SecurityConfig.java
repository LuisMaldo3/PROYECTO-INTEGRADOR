package pe.tecsup.vynk.config;

import com.nimbusds.jose.jwk.source.ImmutableSecret;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtEncoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import pe.tecsup.vynk.service.RevocacionTokens;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    SecurityFilterChain cadena(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())
                .cors(Customizer.withDefaults())
                .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(a -> a
                        .requestMatchers("/auth/login", "/auth/login-password", "/error").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/portadas/archivo/*").permitAll()
                        .anyRequest().authenticated())
                .oauth2ResourceServer(o -> o.jwt(j -> j.jwtAuthenticationConverter(convertidorDeJwt())));
        return http.build();
    }

    /**
     * Convierte el claim "rol" del JWT en una autoridad de Spring Security:
     * "organizador" -> ROLE_ORGANIZADOR. Asi un endpoint puede exigir
     * .hasRole("ORGANIZADOR") o @PreAuthorize("hasRole('ADMINISTRADOR')").
     */
    private JwtAuthenticationConverter convertidorDeJwt() {
        JwtAuthenticationConverter convertidor = new JwtAuthenticationConverter();
        convertidor.setJwtGrantedAuthoritiesConverter(jwt -> {
            String rol = jwt.getClaimAsString("rol");
            if (rol == null || rol.isBlank()) {
                return List.<GrantedAuthority>of();
            }
            return List.<GrantedAuthority>of(
                    new SimpleGrantedAuthority("ROLE_" + rol.trim().toUpperCase(Locale.ROOT)));
        });
        return convertidor;
    }

    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    JwtDecoder jwtDecoder(@Value("${vynk.jwt.secret}") String secret, RevocacionTokens revocacion) {
        NimbusJwtDecoder decoder = NimbusJwtDecoder.withSecretKey(llave(secret)).build();
        // Además de firma y vencimiento, se rechaza el token de una sesión ya cerrada (POST /auth/logout).
        decoder.setJwtValidator(new DelegatingOAuth2TokenValidator<Jwt>(
                JwtValidators.createDefault(),
                new ValidadorTokenRevocado(revocacion::estaRevocado)));
        return decoder;
    }

    @Bean
    JwtEncoder jwtEncoder(@Value("${vynk.jwt.secret}") String secret) {
        return new NimbusJwtEncoder(new ImmutableSecret<>(llave(secret)));
    }

    @Bean
    CorsConfigurationSource corsConfigurationSource(@Value("${vynk.cors.origins}") String[] origenes) {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(Arrays.asList(origenes)); // web de Jordi (CORS_ORIGINS en .env)
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        UrlBasedCorsConfigurationSource fuente = new UrlBasedCorsConfigurationSource();
        fuente.registerCorsConfiguration("/**", config);
        return fuente;
    }

    private SecretKey llave(String secreto) {
        byte[] bytes = secreto.getBytes(StandardCharsets.UTF_8);
        if (bytes.length < 32) {
            // HS256 exige 256 bits; si no, el login fallaria con error 500 recien al emitir el token.
            throw new IllegalStateException(
                    "JWT_SECRET debe tener al menos 32 caracteres (tiene " + bytes.length + "). Revisa tu archivo .env.");
        }
        return new SecretKeySpec(bytes, "HmacSHA256");
    }
}
