import { rutaOrganizador } from '../services/organizadorService'

const estadoTexto = { programada: 'Programada', cancelada: 'Cancelada', finalizada: 'Finalizada', inactiva: 'Inactiva' }

function formatoFecha(fecha) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha || '')) return 'Fecha por confirmar'
  const [year, month, day] = fecha.split('-').map(Number)
  return new Intl.DateTimeFormat('es-PE', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' })
    .format(new Date(Date.UTC(year, month - 1, day)))
}

export function OrganizadorTarjeta({ actividad }) {
  const a = actividad
  const inscritos = Number(a.cuposOcupados ?? a.inscritosRegistrados ?? 0)
  const maximo = a.maximoParticipantes == null ? null : Number(a.maximoParticipantes)
  const progreso = maximo > 0 ? Math.min(100, Math.round((inscritos / maximo) * 100)) : 0
  const disponibles = a.cuposDisponibles
  const estado = String(a.estado || 'programada').toLowerCase()
  return (
    <article className={`org-tarjeta${a.proxima ? ' org-tarjeta--proxima' : ''}`}>
      <div className="org-tarjeta__arriba">
        <span className={`org-estado ${estado === 'cancelada' ? 'org-estado--cancelada' : ''}`}>
          <span className="org-punto" aria-hidden="true" />{estadoTexto[estado] || estado}
        </span>
        <span className="org-tarjeta__id">{a.proxima ? 'PRÓXIMA ACTIVIDAD' : 'ACTIVIDAD'}</span>
      </div>
      <h3>{a.nombre || 'Actividad sin nombre'}</h3>
      <p className="org-tarjeta__descripcion">{a.descripcion || 'Consulta los detalles y gestiona los participantes de tu actividad.'}</p>
      <div className="org-metadatos">
        <span>◷ {formatoFecha(a.fecha)}</span>
        <span>◴ {a.horaInicio || '—'}{a.horaFin ? ` – ${a.horaFin}` : ''}</span>
        <span>⌖ {a.ubicacion || 'Ubicación por confirmar'}</span>
      </div>
      <div className="org-capacidad">
        <div className="org-capacidad__encabezado"><span><strong>{inscritos}</strong> {a.unidadCupo === 'equipos' ? 'equipos registrados' : 'estudiantes inscritos'} {maximo != null ? `de ${maximo}` : ''}</span><span className={disponibles === 0 ? 'org-cupos--llenos' : 'org-cupos--libres'}>{disponibles == null ? 'Cupos por confirmar' : disponibles === 0 ? 'Sin cupos' : `${disponibles} disponibles`}</span></div>
        {a.unidadCupo === 'equipos' && <small>{a.estudiantesInscritos ?? 0} estudiantes · {a.equiposConfirmados ?? 0} equipos habilitados</small>}
        {maximo != null && maximo > 0 && <div className="org-barra" role="progressbar" aria-label="Cupos ocupados" aria-valuenow={Math.min(inscritos, maximo)} aria-valuemin={0} aria-valuemax={maximo}><span style={{ width: `${progreso}%` }} /></div>}
      </div>
      <div className="org-tarjeta__acciones">
        <a className="org-boton org-boton--primario" href={rutaOrganizador('organizador-detalle', a.id)}>
          Ver detalles <span aria-hidden="true">→</span>
        </a>
        <a className="org-boton org-boton--suave" href={rutaOrganizador('organizador-inscritos', a.id)}>Inscritos</a>
        <a className="org-boton org-boton--simple" href={rutaOrganizador('organizador-reporte', a.id)}>Reportar</a>
      </div>
    </article>
  )
}
