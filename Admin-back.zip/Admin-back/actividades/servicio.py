"""US-25 · Tarea 2: lógica de las actividades (sin HTTP). Aquí se valida y se guarda en MongoDB."""
from datetime import datetime, timezone

from . import mongo
from .portadas import normalizar_portada
from .competencias import validar_configuracion
from .areas import normalizar_areas
from .horario import validar_horario
from .cambios_horario import detectar_cambios_horario
from .cambios_ubicacion import detectar_cambio_ubicacion
from usuarios import mongo as mongo_usuarios
from usuarios.vistas_util import buscar_por_id

# Mismos límites y mensajes que la web (Admi-Fron/src/services/validacionActividad.js).
NOMBRE_MIN, NOMBRE_MAX = 3, 80
DESCRIPCION_MIN, DESCRIPCION_MAX = 10, 500


class DatosInvalidos(ValueError):
    """Los datos de la actividad no pasan la revisión. `errores` = { campo: mensaje }."""

    def __init__(self, errores):
        super().__init__("Revisa los datos de la actividad.")
        self.errores = errores


def _texto(valor):
    return valor.strip() if isinstance(valor, str) else ""


def validar(datos):
    """Devuelve (nombre, descripcion, categoria, ubicacion, horario) limpios o lanza DatosInvalidos con todos los errores."""
    datos = datos if isinstance(datos, dict) else {}
    nombre = _texto(datos.get("nombre"))
    descripcion = _texto(datos.get("descripcion"))
    categoria_id = _texto(datos.get("categoriaId"))
    errores = {}

    if not nombre:
        errores["nombre"] = "Escribe el nombre de la actividad."
    elif len(nombre) < NOMBRE_MIN:
        errores["nombre"] = f"El nombre debe tener al menos {NOMBRE_MIN} caracteres."
    elif len(nombre) > NOMBRE_MAX:
        errores["nombre"] = f"El nombre no puede pasar de {NOMBRE_MAX} caracteres."

    if not descripcion:
        errores["descripcion"] = "Escribe una descripción."
    elif len(descripcion) < DESCRIPCION_MIN:
        errores["descripcion"] = f"La descripción debe tener al menos {DESCRIPCION_MIN} caracteres."
    elif len(descripcion) > DESCRIPCION_MAX:
        errores["descripcion"] = f"La descripción no puede pasar de {DESCRIPCION_MAX} caracteres."

    categoria = None
    if not categoria_id:
        errores["categoriaId"] = "Elige una categoría."
    else:
        categoria = mongo.categorias().find_one({"_id": categoria_id})
        if not categoria:
            errores["categoriaId"] = "Elige una categoría válida."

    ubicacion = None
    ubicacion_id = _texto(datos.get("ubicacionId"))
    if not ubicacion_id:
        errores["ubicacionId"] = "Elige una ubicación."
    else:
        ubicacion = mongo.ubicaciones().find_one({"_id": ubicacion_id})
        if not ubicacion:
            errores["ubicacionId"] = "Elige una ubicación válida."

    organizador_id = _texto(datos.get("organizadorId"))
    organizador = buscar_por_id(mongo_usuarios.usuarios(), organizador_id) if organizador_id else None
    if not organizador_id:
        errores["organizadorId"] = "Elige un organizador responsable."
    elif not organizador or organizador.get("rol", "usuario") != "organizador" or not organizador.get("activo", True):
        errores["organizadorId"] = "Elige un organizador activo y válido."

    maximo = datos.get("maximoParticipantes")
    if isinstance(maximo, bool) or not isinstance(maximo, int) or maximo <= 0:
        errores["maximoParticipantes"] = "El máximo de participantes debe ser un entero mayor que cero."

    horario, errores_horario = validar_horario(datos)
    errores.update(errores_horario)

    if errores:
        raise DatosInvalidos(errores)
    return nombre, descripcion, categoria, ubicacion, horario, maximo, organizador


def _iso(fecha):
    # Mongo devuelve fechas sin zona (en UTC): se marca como UTC para que el navegador la convierta bien.
    if fecha.tzinfo is None:
        fecha = fecha.replace(tzinfo=timezone.utc)
    return fecha.isoformat()


def calcular_cupos_disponibles(doc):
    """Cupos restantes, nunca negativos; None para actividades antiguas sin límite."""
    maximo = doc.get("maximoParticipantes")
    if maximo is None:
        return None
    return max(0, maximo - doc.get("participantesInscritos", 0))


def a_json(doc, nombres_categoria, nombres_ubicacion=None):
    categoria_id = doc.get("categoriaId")
    ubicacion_id = doc.get("ubicacionId")
    nombres_ubicacion = nombres_ubicacion or {}
    return {
        "id": str(doc["_id"]),
        "nombre": doc.get("nombre"),
        "estado": doc.get("estado", "programada"),
        "descripcion": doc.get("descripcion"),
        "categoria": {"id": categoria_id, "nombre": nombres_categoria.get(categoria_id, "Sin categoría")},
        # Las actividades viejas, creadas antes de las ubicaciones, no la tienen: ubicacion = None.
        "ubicacion": {"id": ubicacion_id, "nombre": nombres_ubicacion.get(ubicacion_id, "Sin ubicación")} if ubicacion_id else None,
        "fecha": doc.get("fecha"),  # las actividades viejas, creadas antes del horario, no la tienen
        "horaInicio": doc.get("horaInicio"),
        "horaFin": doc.get("horaFin"),
        "maximoParticipantes": doc.get("maximoParticipantes"),
        "participantesInscritos": doc.get("participantesInscritos", 0),
        "cuposDisponibles": calcular_cupos_disponibles(doc),
        "tipoActividad": doc.get("tipoActividad", "actividad"),
        "areaTecsup": doc.get("areaTecsup", ""),
        "encargadosPorArea": doc.get("encargadosPorArea", {}),
        "modalidad": doc.get("modalidad"),
        "maxIntegrantesEquipo": doc.get("maxIntegrantesEquipo"),
        "reglasCompetencia": doc.get("reglasCompetencia", ""),
        "puntosPorPuesto": doc.get("puntosPorPuesto", []),
        "portada": doc.get("portada"),
        "portadaUrl": doc.get("portada", {}).get("url") if isinstance(doc.get("portada"), dict) else None,
        "unidadCupo": "equipos" if doc.get("tipoActividad") == "competencia" and doc.get("modalidad") == "equipos" else "estudiantes",
        "organizadorId": doc.get("organizadorId"),
        "organizador": doc.get("organizador"),
        "creadaPor": doc.get("creadaPor"),
        "creadaEn": _iso(doc["creadaEn"]),
    }


def crear_actividad(datos, admin_id):
    """Valida y guarda una actividad nueva. Devuelve la actividad creada lista para JSON."""
    nombre, descripcion, categoria, ubicacion, horario, maximo, organizador = validar(datos)
    configuracion = validar_configuracion(datos)
    areas = normalizar_areas(datos)
    try:
        portada = normalizar_portada(datos.get("portada"))
    except ValueError as exc:
        raise DatosInvalidos({"portada": str(exc)}) from exc
    doc = {
        "nombre": nombre,
        "estado": "programada",
        "descripcion": descripcion,
        "categoriaId": categoria["_id"],
        "ubicacionId": ubicacion["_id"],
        "maximoParticipantes": maximo,
        "participantesInscritos": 0,
        "portada": portada,
        **configuracion, **areas,
        "organizadorId": str(organizador["_id"]),
        "organizador": {"id": str(organizador["_id"]), "nombre": organizador.get("nombre", "")},
        **horario,
        "creadaPor": str(admin_id),
        "creadaEn": datetime.now(timezone.utc),
    }
    doc["_id"] = mongo.actividades().insert_one(doc).inserted_id
    return a_json(doc, {categoria["_id"]: categoria["nombre"]}, {ubicacion["_id"]: ubicacion["nombre"]})


def modificar_actividad(actividad_id, datos, admin_id=None):
    """Edita campos permitidos sin modificar inscripciones ni metadatos de creación."""
    # Las actividades nuevas tienen ObjectId en Mongo, aunque el URL trae texto.
    # Reutilizar el mismo conversor seguro que el endpoint de cancelación.
    actual = buscar_por_id(mongo.actividades(), actividad_id)
    if actual is None:
        raise LookupError("Actividad no encontrada.")
    actividad_id = actual["_id"]
    if actual.get("estado", "programada") == "cancelada":
        raise DatosInvalidos({"estado": "No se puede editar una actividad cancelada."})
    nombre, descripcion, categoria, ubicacion, horario, maximo, organizador = validar(datos)
    configuracion = validar_configuracion(datos)
    areas = normalizar_areas(datos)
    try:
        portada = normalizar_portada(datos.get("portada", actual.get("portada")))
    except ValueError as exc:
        raise DatosInvalidos({"portada": str(exc)}) from exc
    if inscritos_existentes := actual.get("participantesInscritos", 0):
        if configuracion["tipoActividad"] != actual.get("tipoActividad", "actividad") or configuracion["modalidad"] != actual.get("modalidad"):
            raise DatosInvalidos({"modalidad": "No se puede cambiar el tipo o modalidad con inscripciones activas."})
    inscritos = actual.get("participantesInscritos", 0)
    if maximo < inscritos:
        raise DatosInvalidos({"maximoParticipantes": f"El máximo no puede ser menor que los {inscritos} participantes inscritos."})
    cambios = {"nombre": nombre, "descripcion": descripcion, "categoriaId": categoria["_id"],
               "ubicacionId": ubicacion["_id"], "maximoParticipantes": maximo, "portada": portada, **areas,
               "organizadorId": str(organizador["_id"]),
               "organizador": {"id": str(organizador["_id"]), "nombre": organizador.get("nombre", "")}, **horario, **configuracion}
    # La condición evita reducir cupos si se inscribieron más personas durante la edición.
    filtro = {"_id": actividad_id, "estado": {"$ne": "cancelada"}, "$or": [{"participantesInscritos": {"$lte": maximo}},
                                            {"participantesInscritos": {"$exists": False}}]}
    # Evita aplicar un segundo aviso si otro editor modificó el horario
    # mientras validábamos esta edición.
    cambios_horario = detectar_cambios_horario(actual, cambios)
    cambio_ubicacion = detectar_cambio_ubicacion(actual, cambios)
    if cambios_horario or cambio_ubicacion:
        for campo in (*cambios_horario, *cambio_ubicacion):
            filtro[campo] = actual.get(campo)
    resultado = mongo.actividades().update_one(filtro, {"$set": cambios})
    if not resultado.matched_count:
        raise DatosInvalidos({"maximoParticipantes": "Se registraron nuevas inscripciones. Actualiza y vuelve a intentar."})
    actualizado = mongo.actividades().find_one({"_id": actividad_id})
    respuesta = a_json(actualizado, {categoria["_id"]: categoria["nombre"]}, {ubicacion["_id"]: ubicacion["nombre"]})
    respuesta["cambioHorario"] = bool(cambios_horario)
    respuesta["cambioUbicacion"] = bool(cambio_ubicacion)
    respuesta["avisosGenerados"] = 0
    respuesta["avisarInscritosSolicitado"] = bool((cambios_horario or cambio_ubicacion) and datos.get("avisarInscritos") is True)
    if respuesta["avisarInscritosSolicitado"]:
        from .avisos_horario import crear_avisos_inscritos
        from pymongo.errors import PyMongoError
        try:
            cantidad, inscritos = (0, 0)
            if cambios_horario:
                cantidad, inscritos = crear_avisos_inscritos(actividad_id, nombre, cambios_horario, admin_id)
            if cambio_ubicacion:
                from .notificaciones_inscritos import notificar_cambio_ubicacion
                anterior_id = actual.get("ubicacionId")
                anterior = mongo.ubicaciones().find_one({"_id": anterior_id}) if anterior_id else None
                cuantos, destinatarios = notificar_cambio_ubicacion(
                    actividad_id, nombre, anterior.get("nombre", "ubicación anterior") if anterior else "ubicación anterior",
                    ubicacion["nombre"], admin_id)
                cantidad += cuantos
                inscritos = max(inscritos, destinatarios)
            respuesta["avisosGenerados"] = cantidad
            respuesta["destinatariosDetectados"] = inscritos
        except PyMongoError:
            respuesta["avisosError"] = "Cambios guardados, pero falló el registro de notificaciones."

    return respuesta


def listar_actividades():
    """Todas las actividades por fecha y hora de inicio; las que no tienen fecha (las viejas) van al final."""
    nombres = {c["_id"]: c["nombre"] for c in mongo.categorias().find({})}
    nombres_ubicacion = {u["_id"]: u["nombre"] for u in mongo.ubicaciones().find({})}
    docs = list(mongo.actividades().find({}))
    docs.sort(key=lambda d: (d.get("fecha") is None, d.get("fecha") or "", d.get("horaInicio") or "", d.get("nombre") or ""))
    return [a_json(d, nombres, nombres_ubicacion) for d in docs]


def listar_categorias():
    """Categorías disponibles para el formulario, por nombre."""
    docs = mongo.categorias().find({}).sort("nombre", 1)
    return [{"id": c["_id"], "nombre": c["nombre"]} for c in docs]


def listar_ubicaciones():
    """Ubicaciones disponibles para el formulario, por nombre."""
    docs = mongo.ubicaciones().find({}).sort("nombre", 1)
    return [{"id": u["_id"], "nombre": u["nombre"]} for u in docs]


def cancelar_actividad(actividad_id, admin_id=None):
    """Cancela sin borrar inscripciones; idempotente y con actualización atómica."""
    coleccion = mongo.actividades()
    from usuarios.vistas_util import buscar_por_id
    actual = buscar_por_id(coleccion, actividad_id)
    if actual is None:
        raise LookupError("Actividad no encontrada.")
    actividad_id = actual["_id"]
    if actual.get("estado", "programada") == "cancelada":
        raise DatosInvalidos({"estado": "La actividad ya está cancelada."})
    resultado = coleccion.update_one(
        {"_id": actividad_id, "estado": {"$ne": "cancelada"}},
        {"$set": {"estado": "cancelada", "canceladaEn": datetime.now(timezone.utc)}}
    )
    if not resultado.matched_count:
        raise DatosInvalidos({"estado": "La actividad ya fue cancelada."})
    doc = coleccion.find_one({"_id": actividad_id})
    categorias = {c["_id"]: c["nombre"] for c in mongo.categorias().find({})}
    ubicaciones = {u["_id"]: u["nombre"] for u in mongo.ubicaciones().find({})}
    respuesta = a_json(doc, categorias, ubicaciones)
    respuesta["avisosGenerados"] = 0
    try:
        from .notificaciones_inscritos import notificar_cancelacion
        cantidad, destinatarios = notificar_cancelacion(actividad_id, doc.get("nombre", "Actividad"), admin_id)
        respuesta["avisosGenerados"] = cantidad
        respuesta["destinatariosDetectados"] = destinatarios
    except Exception as error:
        # No revertir una cancelación ya guardada cuando el envío falla.
        from pymongo.errors import PyMongoError
        if not isinstance(error, PyMongoError):
            raise
        respuesta["avisosError"] = "Actividad cancelada; no se pudieron registrar las notificaciones."
    return respuesta
